/* calcular las 4 notas y sacar un promedio */
#include <iostream>
using namespace std;

int main ()
{
	float nota1,nota2,nota3,nota4; //notas 
	float promedio_notas;
	cout<<"ingrese nota  1=  ";
	cin>>nota1;
	cout<<"ingrese nota  2=  ";
	cin>>nota2;
	cout<<"ingrese nota  3=  ";
	cin>>nota3;
	cout<<"ingrese nota 4=  ";
	cin>>nota4;
	promedio_notas= (nota1+nota2+nota3+nota4)/4;
	cout<<"el promedio de las notas es=  "<<promedio_notas;
	
	return 0;
}

