/* calcular la edad del usuario*/
#include <iostream>
using namespace std;

int main ()
{
	int anoactual,anonacimiento,menoredad,mayoredad; //edad
	
	cout<<"ingrese el año actual ";
	cin>>anoactual;
	cout<<"ingrese año de nacimiento  ";
	cin>>anonacimiento;
	mayoredad=18;
	if(menoredad<(anoactual-anonacimiento))
	{
		cout<<"usted es menor  de edad ";
		
	}
	else
	
		
		if(mayoredad>(anoactual-anonacimiento))
		{
			cout<<"usted es menor de edad ";
		}
			
	
}